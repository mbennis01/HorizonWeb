﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace APIRSSReader.RazorModel 
{
    class Response
    {
        [JsonProperty("coarseTopics")]
        public List<Topic> coarseTopics = new List<Topic>();

        [JsonProperty("language")]
        public string language;

        [JsonProperty("languageIsReliable")]
        public Boolean languageIsReliable;

        [JsonProperty("topics")]
        public List<Topic> topics = new List<Topic>();

        [JsonProperty("time")]
        public float time;

        [JsonProperty("Ok")]
        public Boolean Ok;

        public Response() { }
    }
}
