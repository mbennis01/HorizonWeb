﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace APIRSSReader.RazorModel
{
    class Topic
    {
        [JsonProperty("id")]
        public int id;

        [JsonProperty("label")]
        public string label;

        [JsonProperty("wikiLink")]
        public string wikiLink;

        [JsonProperty("score")]
        public double score;

        public Topic() { }
    }
}
