﻿using APIRSSReader.RazorModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIRSSReader.Models
{
    public class TextRazorClassifieur2
    {
        private List<string> categories = new List<string>(new string[] { "Violence", "Politics", "Nature", "Technology", "Business", "Culture", "Sports", "Health", "Science" });
        private TextRazor2 textRazor = new TextRazor2();
        Wrapper wrapper = null;

        public string classify(Article a)
        {
            try
            {
                wrapper = textRazor.makeRequest(a.Titre);
            }
            catch (Exception e)
            {
                return "delete";
            }
            if (wrapper.response.coarseTopics.Count == 0)
            {
                try
                {
                    wrapper = textRazor.makeRequest(a.Description);
                }
                catch (Exception e)
                {
                    return "delete";
                }

                if (wrapper.response.coarseTopics.Count == 0)
                {
                    return "delete";
                }
                else
                {
                    foreach (Topic t in wrapper.response.coarseTopics)
                    {
                        if (t.score > 0.97)
                        {
                            var index = this.categories.IndexOf(t.label);
                            if (index != -1)
                            {
                                return t.label;
                            }
                        }
                    }
                    return "delete";
                }
            }
            else
            {
                foreach (Topic t in wrapper.response.coarseTopics)
                {
                    if (t.score > 0.97)
                    {
                        var index = this.categories.IndexOf(t.label);
                        if (index != -1)
                        {
                            return t.label;
                        }
                    }
                }
                return "delete";
            }
        }
    }
}