﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIRSSReader.Models
{
    public class Commentaire
    {
        public string IdUtilisateur { get; set; }
        public string IdArticle { get; set; }
        public string Contenu { get; set; }
    }
}