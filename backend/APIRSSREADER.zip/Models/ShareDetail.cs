﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIRSSReader.Models
{
    public class ShareDetail
    {
        public string Ida { get; set; }
        public string Idaf { get; set; }
        public string Date { get; set; }
        public string Idu { get; set; }
    }
}