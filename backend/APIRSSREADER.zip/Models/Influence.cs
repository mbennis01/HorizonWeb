﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIRSSReader.Models
{
    public class Influence
    {
        public int Like_no_badge { get; set; }
        public int Share_no_badge { get; set; }
        public int User_for_like { get; set; }
        public int User_for_share { get; set; }
        public int Like_bronze { get; set; }
        public int Like_silver { get; set; }
        public int Like_gold { get; set; }
        public int Share_bronze { get; set; }
        public int Share_silver { get; set; }
        public int Share_gold { get; set; }
    }
}