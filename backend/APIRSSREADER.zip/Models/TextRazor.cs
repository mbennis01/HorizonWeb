﻿using APIRSSReader.RazorModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace APIRSSReader.Models
{

    public enum verb
    {
        GET,
        POST,
        PUT,
        DELETE
    }

    class TextRazor
    {
        public string endPoint { get; set; }
        public verb httpVerb { get; set; }

        public TextRazor()
        {
            endPoint = String.Empty;
            endPoint = "https://api.textrazor.com/";
            httpVerb = verb.POST;
        }

        public Wrapper makeRequest(string text)
        {
            HttpWebRequest httpWebRequest = HttpWebRequest.CreateHttp(this.endPoint);

            string postData = "extractors=topics&text=" + text;
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(postData);

            httpWebRequest.Method = verb.POST.ToString();
            httpWebRequest.ContentType = "application/x-www-form-urlencoded";
            httpWebRequest.Headers.Add("x-textrazor-key", "67ffadd349385be1dc8fef52a4d6cca15df4992c9fb16715431fdbf2");
            httpWebRequest.ContentLength = byte1.Length;

            Stream stream = httpWebRequest.GetRequestStream();
            stream.Write(byte1, 0, byte1.Length);
            stream.Close();

            WebResponse response = httpWebRequest.GetResponse();
            stream = response.GetResponseStream();

            StreamReader reader = new StreamReader(stream);
            Wrapper wrapper = JsonConvert.DeserializeObject<Wrapper>(reader.ReadToEnd());

            return wrapper;
        }
    }
}
