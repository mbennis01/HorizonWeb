﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APIRSSReader.Models
{
    public class Utilisateur
    {
        public long Id_user { get; set; }
        public string Nom { get; set; }
        public int Score1 { get; set; }
        public int Score2 { get; set; }
        public int Score3 { get; set; }
        public int Score4 { get; set; }
        public int Score5 { get; set; }
        public int Score6 { get; set; }
        public int Score7 { get; set; }
        public int Score8 { get; set; }
        public int Score9 { get; set; }
        //public int Score10 { get; set; }
        //public int Score11 { get; set; }
        //public int Score12 { get; set; }
        public int Sicture { get; set; }
        public string Picture { get; set; }
        public int Badge { get; set; }
        public string Role { get; set; }
    }
}