﻿using APIRSSReader.Models;
using APIRSSReader.Models.Persistance;
using System;
using System.Collections.Generic;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using System.Web.Http;
using System.IdentityModel.Tokens.Jwt;
using System.Threading;

namespace APIRSSReader.Controllers
{
    public class ArticlesController : ApiController
    {
        /*Chaine de connexion à la base de données*/
        /*CHAINE DEVELOPEMENT*/
        //private static string CONNECTION_STRING = "server=localhost;database=horizon;uid=root;pwd=";
        DataBaseCommunication dataBaseCommunication = new DataBaseCommunication(CONNECTION_STRING);


        /*CHAINE PRODUCTION*/
        private static string CONNECTION_STRING = "server=localhost;database=horizonapp_fr_botella;uid=botella;pwd=aaaaaa12";

        // GET: api/Articles
        /*Pour récupérer tous les article depuis la base de données*/
        public List<Article> Get()
        {
            return dataBaseCommunication.GetArticles();
        }

        [Route("api/articles/{a}")]
        [HttpGet]
        public List<Article> GetByLimits(int a)
        {
            return dataBaseCommunication.GetArticlesByLimits(a);
        }


        // POST: api/Articles
        /*Pour insérer des articles à la base de données, nécessite une authentification via json, cf class person*/
        [Route("api/articles")]
        [HttpGet]
        public void Post([FromBody]Person person)
        {
            if (person.Login.Equals("CiPhantom") && person.Password.Equals("lksPMnze"))
            {

                OpmlHandler opmlHandler = new OpmlHandler("./rss.opml");
                Dictionary<string, string> urls = new Dictionary<string, string>();
                urls = opmlHandler.getListeJourneaux();

                List<Article> articles = new List<Article>();
                Feeder f = new Feeder(urls);
                articles = f.getArticles();

                dataBaseCommunication.SaveArticles(articles);
            }
        }

        [Route("api/articles2")]
        [HttpGet]
        public void Post2([FromBody]Person person)
        {
            if (person.Login.Equals("CiPhantom") && person.Password.Equals("lksPMnze"))
            {

                OpmlHandler opmlHandler = new OpmlHandler("./rss.opml");
                Dictionary<string, string> urls = new Dictionary<string, string>();
                urls = opmlHandler.getListeJourneaux();

                List<Article> articles = new List<Article>();
                Feeder f = new Feeder(urls);
                articles = f.getArticles();

                dataBaseCommunication.SaveArticles2(articles);
            }
        }

        //[FilterIP(AllowedSingleIPs = "91.216.107.196")]
        [Route("api/getarticlestoserver")]
        [HttpGet]
        public string Post3()
        {
            new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;
                OpmlHandler opmlHandler = new OpmlHandler("./rss.opml");
                Dictionary<string, string> urls = new Dictionary<string, string>();
                urls = opmlHandler.getListeJourneaux();

                List<Article> articles = new List<Article>();
                Feeder f = new Feeder(urls);
                articles = f.getArticles();

                int inserted = dataBaseCommunication.SaveArticles2(articles);
            }).Start();

            return "Thread lunched with success ! ";
        }

        [Route("api/articles/postuser")]
        [HttpPost]
        public Boolean PostUser([FromBody] User user)
        {
            return dataBaseCommunication.AddUser(user);
        }

        [Route("api/articles/updatepicture")]
        [HttpPut]
        public Boolean UpdatePicture([FromBody] User user)
        {
            return dataBaseCommunication.UpdatePicture(user);
        }

        [Route("api/articles/updatebadge/{b}")]
        [HttpPut]
        public Boolean UpdateBadge([FromBody] User user, Boolean b)
        {
            return dataBaseCommunication.UpdateBadge(user, b);
        }

        [Route("api/articles/postuserdesktop")]
        [HttpPost]
        public IHttpActionResult PostUserdesktop([FromBody] User user)
        {
            if (dataBaseCommunication.AddUser(user))
            {
                var header = Request.Headers.Authorization;
                if (header.ToString().StartsWith("Basic"))
                {
                    string[] values = { user.Id, user.Nom, user.Picture };
                    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("qdsfiy7748qgsfd"));
                    var signinCred = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);
                    var claims = new[] { new Claim("Id", values[0]), new Claim("Nom", values[1]) };
                    var tokenSecurity = new JwtSecurityToken(
                        issuer: "horizonapp.fr",
                        audience: "horizonapp.fr",
                        expires: DateTime.Now.AddDays(5),
                        claims: claims,
                        signingCredentials: signinCred
                        );
                    var token = new JwtSecurityTokenHandler().WriteToken(tokenSecurity);
                    return Ok(token);
                }
                else
                {
                    return BadRequest("Bad request error when creating token");
                }
            }
            return BadRequest("Bad request error when adding user");
        }

        [Route("api/articles/checkuser")]
        [HttpPost]
        public Boolean CheckUser([FromBody] User user)
        {
            return dataBaseCommunication.CheckUser(user);
        }

        [Route("api/articles/user/{id}")]
        [HttpGet]
        public Utilisateur GetUtilisateur(string id)
        {
            return dataBaseCommunication.GetUtilisateur(id);
        }

        [Route("api/articles/checkuserdesktop")]
        [HttpPost]
        public IHttpActionResult CheckUserDesktop([FromBody] User user)
        {
            var header = Request.Headers.Authorization;
            if (header.ToString().StartsWith("Basic"))
            {
                if (dataBaseCommunication.CheckUser(user))
                {
                    var utilisateur = this.GetUtilisateur(user.Id);

                    var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("layn3elDinMMokYal9a7ba"));
                    var signinCred = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);
                    var claims = new[] {
                        new Claim("Id_user", utilisateur.Id_user.ToString()),
                        new Claim("Nom", utilisateur.Nom),
                        new Claim("Score1", utilisateur.Score1.ToString()),
                        new Claim("Score2", utilisateur.Score2.ToString()),
                        new Claim("Score3", utilisateur.Score3.ToString()),
                        new Claim("Score4", utilisateur.Score4.ToString()),
                        new Claim("Score5", utilisateur.Score5.ToString()),
                        new Claim("Score6", utilisateur.Score6.ToString()),
                        new Claim("Score7", utilisateur.Score7.ToString()),
                        new Claim("Score8", utilisateur.Score8.ToString()),
                        new Claim("Score9", utilisateur.Score9.ToString()),
                        //new Claim("Score10", utilisateur.Score10.ToString()),
                        //new Claim("Score11", utilisateur.Score11.ToString()),
                        //new Claim("Score12", utilisateur.Score12.ToString()),
                        new Claim("Picture", utilisateur.Picture),
                        new Claim("badge", utilisateur.Badge.ToString()),
                        new Claim("Role", utilisateur.Role)
                    };
                    var tokenSecurity = new JwtSecurityToken(
                        issuer: "horizonapp.fr",
                        audience: "horizonapp.fr",
                        expires: DateTime.Now.AddDays(5),
                        claims: claims,
                        signingCredentials: signinCred
                    );
                    var token = new JwtSecurityTokenHandler().WriteToken(tokenSecurity);
                    return Ok(token);
                }
                else
                {
                    return Ok("NoUserDetected");
                }
            }
            else
            {
                return BadRequest("test bad request " + header);
            }
        }

        [Route("api/articles/checkShare")]
        [HttpPost]
        public Boolean CheckShare([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.CheckShare(shareModel);
        }

        [Route("api/articles/getcomment/{id}")]
        [HttpGet]
        public List<Comment> getComments(string id)
        {
            return dataBaseCommunication.getComments(id);
        }

        [Route("api/articles/checkLike")]
        [HttpPost]
        public Boolean CheckLike([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.CheckLike(shareModel);
        }

        [Route("api/articles/InsertShare")]
        [HttpPost]
        public Boolean InsertShare([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.InsertShare(shareModel);
        }

        [Route("api/articles/InsertLike")]
        [HttpPost]
        public Boolean InsertLike([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.InsertLike(shareModel);
        }

        [Route("api/articles/InsertShareBadge")]
        [HttpPost]
        public Boolean InsertShareBadge([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.InsertShareBadge(shareModel);
        }

        [Route("api/articles/InsertLikeBadge")]
        [HttpPost]
        public Boolean InsertLikeBadge([FromBody] ShareModel shareModel)
        {
            return dataBaseCommunication.InsertLikeBadge(shareModel);
        }

        [Route("api/articles/RemoveLikeBadge/{idu}/{ida}")]
        [HttpDelete]
        public Boolean RemoveLikeBadge(string idu, string ida)
        {
            return dataBaseCommunication.RemoveLikeBadge(idu, ida);
        }

        [Route("api/articles/GetLikedArticlesByUser/{id}")]
        [HttpGet]
        public List<Article> GetLikedArticlesByUser(string id)
        {
            return dataBaseCommunication.GetLikedArticlesByUser(id);
        }

        [Route("api/articles/PostComment")]
        [HttpPost]
        public string PostComment([FromBody] Commentaire commentaire)
        {
            return dataBaseCommunication.PostCommentaire(commentaire);
        }

        [Route("api/articles/UserScores/{id}")]
        [HttpGet]
        public List<int> GetScores(string id)
        {
            return dataBaseCommunication.GetScores(id);
        }

        [Route("api/articles/like/{ida}/{idu}")]
        [HttpDelete]
        public Boolean removeLike(string ida, string idu)
        {
            return dataBaseCommunication.RemoveLike(ida, idu);
        }

        [Route("api/articles/sharedetails")]
        [HttpPost]
        public string addShareDetails([FromBody] ShareDetail shareDetail)
        {
            return dataBaseCommunication.addShareDetails(shareDetail.Ida, shareDetail.Idaf, shareDetail.Date, shareDetail.Idu);
        }

        [Route("api/articles/idafs/{idu}")]
        [HttpGet]
        public List<string> getIdafsUser(string idu)
        {
            return dataBaseCommunication.getIdafsUsers(idu);
        }

        [Route("api/articles/idafs/{idu}/{idaf}")]
        [HttpDelete]
        public Boolean removeShareDetails(string idu, string idaf)
        {
            return dataBaseCommunication.removeShareDetails(idu, idaf);
        }

        [Route("api/articles/users")]
        [HttpGet]
        public List<Utilisateur> getAllUsers()
        {
            return dataBaseCommunication.getAllUsers();
        }

        [Route("api/articles/admin/{id}")]
        [HttpPut]
        public Boolean addAdmin(string id)
        {
            return dataBaseCommunication.addAdmin(id);
        }

        [Route("api/articles/adminr/{id}")]
        [HttpPut]
        public Boolean removeAdmin(string id)
        {
            return dataBaseCommunication.removeAdmin(id);
        }

        [Route("api/articles/executor")]
        [HttpPost]
        public string executor([FromBody] Request request)
        {
            return dataBaseCommunication.executor(request);
        }

        [Route("api/articles/seuils")]
        [HttpGet]
        public Seuils getSeuils()
        {
            return dataBaseCommunication.getSeuils();
        }

        [Route("api/articles/seuilsbronze")]
        [HttpPut]
        public IHttpActionResult updateBronze([FromBody] Seuils seuils)
        {
            return Ok(dataBaseCommunication.updateBronze(seuils));
        }

        [Route("api/articles/seuilssilver")]
        [HttpPut]
        public IHttpActionResult updateSilver([FromBody] Seuils seuils)
        {
            return Ok(dataBaseCommunication.updateSilver(seuils));
        }

        [Route("api/articles/seuilsgold")]
        [HttpPut]
        public IHttpActionResult updateGold([FromBody] Seuils seuils)
        {
            return Ok(dataBaseCommunication.updateGold(seuils));
        }

        [Route("api/articles/influences")]
        [HttpGet]
        public Influence getInfluences()
        {
            return dataBaseCommunication.getInfluences();
        }

        [Route("api/articles/influencesLike_no_badge")]
        [HttpPut]
        public IHttpActionResult updateGold([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateLike_no_badge(influences));
        }

        [Route("api/articles/influencesShare_no_badge")]
        [HttpPut]
        public IHttpActionResult updateShare_no_badge([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateShare_no_badge(influences));
        }

        [Route("api/articles/influencesUser_for_like")]
        [HttpPut]
        public IHttpActionResult updateUser_for_like([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateUser_for_like(influences));
        }

        [Route("api/articles/influencesUser_for_share")]
        [HttpPut]
        public IHttpActionResult updateUser_for_share([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateUser_for_share(influences));
        }

        [Route("api/articles/influencesLike_bronze")]
        [HttpPut]
        public IHttpActionResult updateLike_bronze([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateLike_bronze(influences));
        }

        [Route("api/articles/influencesLike_silver")]
        [HttpPut]
        public IHttpActionResult updateLike_silver([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateLike_silver(influences));
        }

        [Route("api/articles/influencesLike_gold")]
        [HttpPut]
        public IHttpActionResult updateLike_gold([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateLike_gold(influences));
        }

        [Route("api/articles/influencesShare_bronze")]
        [HttpPut]
        public IHttpActionResult updateShare_bronze([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateShare_bronze(influences));
        }

        [Route("api/articles/influencesShare_silver")]
        [HttpPut]
        public IHttpActionResult updateShare_silver([FromBody] Influence influences)
        {
            return Ok(dataBaseCommunication.updateShare_silver(influences));
        }

        [Route("api/articles/badgeon/{id}")]
        [HttpPut]
        public IHttpActionResult giveBadge(string id)
        {
            return Ok(dataBaseCommunication.giveBadge(id));
        }

        [Route("api/articles/badgeoff/{id}")]
        [HttpPut]
        public IHttpActionResult removeBadge(string id)
        {
            return Ok(dataBaseCommunication.removeBadge(id));
        }

        [Route("api/articles/regression")]
        [HttpGet]
        public IHttpActionResult doRegression()
        {
            return Ok(dataBaseCommunication.doRegression());
        }

        [Route("api/articles/newpoint/{value}")]
        [HttpPut]
        public IHttpActionResult setNewPoint(int value)
        {
            return Ok(dataBaseCommunication.setNewPoint(value));
        }

        [Route("api/articles/newpoint")]
        [HttpGet]
        public int getNewPoint()
        {
            return dataBaseCommunication.getNewPoint();
        }

        [Route("api/articles/sources")]
        [HttpGet]
        public List<string> getSources()
        {
            return dataBaseCommunication.getsources();
        }

        [Route("api/articles/sources/{source}")]
        [HttpGet]
        public int getSourceScore(string source)
        {
            return dataBaseCommunication.getSourceScore(source);
        }

        [Route("api/articles/{source}/{bonus}")]
        [HttpPost]
        public IHttpActionResult addBonusToSource(string source, int bonus)
        {
            return Ok(dataBaseCommunication.addBonusToSource(source, bonus));
        }

        [Route("api/articles/sources/counter/{source}")]
        [HttpGet]
        public int sourceCounter(string source)
        {
            return dataBaseCommunication.sourceCounter(source);
        }

        [Route("api/articles/sources/new/{source}")]
        [HttpGet]
        public int getNewBySource(string source)
        {
            return dataBaseCommunication.getNewBySource(source);
        }

        [Route("api/articles/sources/old/{source}")]
        [HttpGet]
        public int getOldBySource(string source)
        {
            return dataBaseCommunication.getOldBySource(source);
        }

        [Route("api/articles/unclassified")]
        [HttpGet]
        public List<Article> getUnclassified()
        {
            return this.dataBaseCommunication.getUnclassified();
        }

        [Route("api/articles/classification")]
        [HttpPost]
        public IHttpActionResult classifyArticle([FromBody] Article article)
        {
            return Ok(this.dataBaseCommunication.classifyArticle(article));
        }

        [Route("api/articles/categories")]
        [HttpGet]
        public List<ArticleCategory> GetCategories()
        {
            return this.dataBaseCommunication.getCategories();
        }

        [Route("api/articles/tracks/{id}")]
        [HttpGet]
        public List<Track> getTrackList(int id)
        {
            return this.dataBaseCommunication.getTrackList(id);
        }

        [Route("api/articles/average")]
        [HttpPost]
        public string calculAverageBySource()
        {
            return this.dataBaseCommunication.calculAverageBySource();
        }
    }
}
