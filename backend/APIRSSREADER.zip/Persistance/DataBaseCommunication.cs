﻿using MySql.Data.MySqlClient;
using APIRSSReader.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace APIRSSReader.Models.Persistance
{
    public class DataBaseCommunication
    {
        public MySqlConnection connection;
        public string urlConnection = "";

        /*      ICI C'EST LES VALEURS DES ACTIONS DANS L'APPLICATION HORIZON nobadge */
        /**/ public static int VALEUR_LIKE_NOBADGE;                                /**/
        /**/ public static int VALEUR_PARTAGE_NOBADGE;                             /**/
        /*****************************************************************************/

        /* ICI LES GAINS PAR ACTION DE L'UTILISATEUR pour L'UTILISATEUR, UTILISÉ QUE DANS L'APPLI AVEC BADGE */
        /**/ public static int GAIN_UTILISATEUR_PAR_PARTAGE = 5;                                           /**/
        /**/ public static int GAIN_UTILISATEUR_PAR_LIKE = 3;                                              /**/
        /*****************************************************************************************************/

        /*ICI LES GAINS PAR ACTION DE L'UTILISATEUR pour L'ARTICLE, UTILISÉ QUE DANS L'APPLI AVEC BADGE */
        /************************* PARTAGE **************************************************************/
        /**/ public static int SCORE_ARTICLE_OR_PARTAGE = 6;                                          /**/
        /**/ public static int SCORE_ARTICLE_ARGENT_PARTAGE = 5;                                      /**/
        /**/ public static int SCORE_ARTICLE_BRONZE_PARTAGE = 4;                                      /**/
        /************************************************************************************************/
        /************************** LIKE ****************************************************************/
        /**/ public static int SCORE_ARTICLE_OR_LIKE = 6;                                             /**/
        /**/ public static int SCORE_ARTICLE_ARGENT_LIKE = 4;                                         /**/
        /**/ public static int SCORE_ARTICLE_BRONZE_LIKE = 2;                                         /**/
        /************************************************************************************************/

        /************************ LES SEUILS POUR ATTEINDRE UN PALLIER DE BADGE *************************/
        /**/ public static int SEUIL_BRONZE;                                                          /**/
        /**/ public static int SEUIL_ARGENT;                                                          /**/
        /**/ public static int SEUIL_OR;                                                              /**/
        /************************************************************************************************/

        /*constructeur de la classe qui permet la connexion avec la base de donnees.
         * le constructeur prend en parametre l'url de la base de donnees.
         * 
         * exemple:
         * DataBaseCommunication dataBaseCommunication = 
                new DataBaseCommunication("server=127.0.0.1 ;database=nom_base_donnees;uid=root;pwd=mot_de_passe");
         */

            //1
        public DataBaseCommunication(string UrlConnection)
        {

            try
            {
                connection = new MySqlConnection(UrlConnection);
                connection.Open();
                this.urlConnection = UrlConnection;
                Console.WriteLine("Connection Succesded");
                this.connection.Close();
                internalUpdateSeuils();
                internalUpdateInfluence();
            }
            catch (MySqlException e)
            {
                Console.WriteLine("DataBase opening failed! Maybe bad url connection ?" + e.Message);
                this.connection.Close();
            }
        }

            //2
        private void internalUpdateSeuils()
        {
            var Seuils = this.getSeuils();
            SEUIL_BRONZE = Seuils.Bronze;
            SEUIL_ARGENT = Seuils.Silver;
            SEUIL_OR = Seuils.Gold;
        }

            //3
        private void internalUpdateInfluence()
        {
            var influences = this.getInfluences();
            VALEUR_LIKE_NOBADGE = influences.Like_no_badge;
            VALEUR_PARTAGE_NOBADGE = influences.Share_no_badge;
        }

        /*
         * la fonction CheckUser permet de versifier si l'utilisateur en paramètre existe ou pas dans la base de données.
         * la fonction retourne true ou false.
        */

            //4
        public Boolean CheckUser(User user)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM utilisateur where id_user= " + user.Id + " and nom = '"
                + user.Nom.Replace("'", "''") + "'";
            MySqlDataReader msdr = cmd.ExecuteReader();
            while (msdr.Read())
            {
                this.connection.Close();
                return true;
            }
            this.connection.Close();
            return false;
        }

        /*
         * fonction qui permet d'ajouter un utilisateur mis en paramètre à la base de données.
         * la fonction retourne true si l'utilisateur a bien été ajouté à la base de données.
        */

            //5
        public Boolean AddUser(User user)
        {
            if (CheckUser(user))
            {
                this.connection.Close();
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "insert into utilisateur(id_user, nom, picture) values (" + user.Id + ",'" + user.Nom.Replace("'", "''") + "', '" + user.Picture.Replace("'", "''") + "')";
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    return true;
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }

            }
        }

        /*
         * cette fonction permet d'inserer les articles du flux rss dans la base de données.
         * la fonction prend en paramètre une liste d'articles.
         * les articles de la liste en paramètres sont traduits en anglais, pour ensuite recuperer leur catégorie.
         * les articles sont insérés dans la tables "article" de la database avec une reference à leur catégorie.
         * les articles sans images ont la colonne "image" vide dans la table "article" dans la base de données.
         
        */

        public int SaveArticles2(List<Article> articles)
        {
            int inserted = 0;
            connection = new MySqlConnection(this.urlConnection);
            MySqlCommand cmd = this.connection.CreateCommand();
            string classified = String.Empty;
            connection.Open();
            TextRazorClassifieur classifieur = new TextRazorClassifieur();
            foreach (Article article in articles)
            {
                classified = String.Empty;
                Boolean b = this.checkArticleByLink(article.Link);
                //classify ne peut être executé que 500 fois. Sa consommation doit être bien conditionnée. 
                if (!b && article.Image != null)
                {
                    classified = classifieur.classify(article);
                    connection.Open();
                }

                int categorie = getTextCategory2(classified);

                if(categorie == 0 && !b && article.Image != null)
                {
                    this.insertUnclassified(article);
                }

                if(categorie != 0 && article.Image != null && !b)
                {
                    string statement = String.Empty;
                    int score = this.getNewPoint();

                        statement = "INSERT INTO article (source, titre, link, description, image, categorie, score) values ('"
                       + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                       + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
                       + article.Image.Replace("'", "''") + "', "
                       + categorie + ", "+score+")";
                    
                    try
                    {
                        cmd.CommandText = statement;
                        cmd.ExecuteNonQuery();
                        inserted++;
                        cmd.CommandText = String.Empty;
                    }
                    catch (MySqlException e)
                    {
                        Console.WriteLine("Cette requête cause problème : " + statement
                            + " \n The exception say " + e.Message);
                    }
                }
            }
            connection.Close();
            return inserted;
        }

        //6
        public void SaveArticles(List<Article> articles)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();

            YandexTranslator translator = new YandexTranslator();
            DatumboxAPI DatumboxAPI = new DatumboxAPI("35e089c310ba09d172e9aee276877ba4");

            foreach (Article article in articles)
            {
                string texte = translator.translate(article.Description);
                Category category = JsonConvert.DeserializeObject<Category>(DatumboxAPI.TopicClassification(texte));
                int categorie = getTextCategory(category.output.result);

                string statement = String.Empty;
                if (article.Image == null)
                {
                    statement = "INSERT INTO article (source, titre, link, description, categorie) values ('"
                    + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                    + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', "
                    + categorie + ")";
                }
                else
                {
                    statement = "INSERT INTO article (source, titre, link, description, image, categorie) values ('"
                   + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                   + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
                   + article.Image.Replace("'", "''") + "', "
                   + categorie + ")";
                }

                try
                {
                    this.connection.Open();
                    cmd.CommandText = statement;
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = String.Empty;
                }
                catch (MySqlException e)
                {
                    Console.WriteLine("Cette requête cause problème : " + statement
                        + " \n The exception say " + e.Message);
                }
            }
            connection.Close();
        }

        /*
         * fonction qui retourne le numero de la catégorie defini dans la base de donnees.
         * la fonction prend un texte en paramètre et retourne son l'id de la catégorie sous forme de type entier.
         */

            //7
        public int getTextCategory(string text)
        {
            this.connection.Close();
            switch (text)
            {
                case "Science":
                    return 9;
                case "Arts":
                    return 1;
                case "Business & Economy":
                    return 2;
                case "Computers & Technology":
                    return 3;
                case "Health":
                    return 4;
                case "Home & Domestic Life":
                    return 5;
                case "News":
                    return 8;
                case "Recreation & Activities":
                    return 6;
                case "Reference & Education":
                    return 7;
                case "Shopping":
                    return 10;
                case "Society":
                    return 11;
                case "Sports":
                    return 12;
                default:
                    return 8;
            }
        }

        public int getTextCategory2(string text)
        {
            this.connection.Close();
            switch (text)
            {
                case "Culture":
                    return 1;
                case "Violence":
                    return 8;
                case "Politics":
                    return 5;
                case "Technology":
                    return 3;
                case "Health":
                    return 4;
                case "Nature":
                    return 6;
                case "Science":
                    return 7;
                case "Business":
                    return 2;
                case "Sports":
                    return 9;
                default:
                    return 0;
            }
        }

        /*
         * la fonction retourne tous les articles stockés dans la base de données.
         * les articles retournés sont structurés dans une liste d'articles.
         */

        //8
        public List<Article> GetArticles()
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            List<Article> articles = new List<Article>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select a.*, c.*, (score + avg_source) as avgs from article a, categorie c where a.categorie = c.id_categorie ORDER BY avgs desc, RAND()";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Id = mySqlDataReader.GetInt32(0).ToString();
                article.Source = mySqlDataReader.GetString(1);
                article.Titre = mySqlDataReader.GetString(2);
                article.Link = mySqlDataReader.GetString(3);
                article.Description = mySqlDataReader.GetString(4);
                try
                {
                    article.Image = mySqlDataReader.GetString(5);
                    article.Categorie = mySqlDataReader.GetString(12);
                }
                catch
                {
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(6);
                article.PublishDate = mySqlDataReader.GetDateTime(8).ToString();
                articles.Add(article);
            }
            mySqlDataReader.Close();
            this.connection.Close();
            return articles;
        }

        /*
         * la fonction retourne un nombre limité définis d'articles depuis la base de données.
         * la fonction prend en paramètre le nombre d'article désiré.
         */

            //9
        public List<Article> GetArticlesByLimits(int a)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            List<Article> articles = new List<Article>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select * from article a, categorie c where a.categorie = c.id_categorie ORDER BY score desc, RAND() LIMIT "+a+", 10;";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Id = mySqlDataReader.GetInt32(0).ToString();
                article.Source = mySqlDataReader.GetString(1);
                article.Titre = mySqlDataReader.GetString(2);
                article.Link = mySqlDataReader.GetString(3);
                article.Description = mySqlDataReader.GetString(4);
                try
                {
                    article.Image = mySqlDataReader.GetString(5);
                    article.Categorie = mySqlDataReader.GetString(12);
                }
                catch
                {
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(6);
                article.PublishDate = mySqlDataReader.GetDateTime(8).ToString();
                articles.Add(article);
            }
            mySqlDataReader.Close();
            this.connection.Close();
            return articles;
        }

        /*
         * la fonction retourne les données d'un article à partir de son lien mis en parmètre.
         */

            //10
        public int getIdArtcileByLink(string link)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            string id_article = String.Empty;
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT id_article FROM article where link = \"" + link + "\" ;";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
            if (mySqlDataReader.Read())
            {
                id_article = mySqlDataReader.GetString(0);
                if (id_article != string.Empty)
                {
                    id_article = mySqlDataReader.GetString(0).ToString();
                }
            }
            int IdArticle = Int32.Parse(id_article);
            this.connection.Close();
            return IdArticle;
        }

        public Boolean checkArticleByLink(string link)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            string id_article = String.Empty;
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT id_article FROM article where link = \"" + link + "\" ;";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
            if (mySqlDataReader.Read())
            {
                this.connection.Close();
                return true; 
            }
            this.connection.Close();
            return false;
        }



        /*
         * la fonction verifie si un article a deja été partagé par un certain utilisateur.
         * la fonction prend en paramètre un objet de type ShareModel.
         * ShareModel cotient une combinaison (id utilisateur, lien article).
         * si cette combianison existe deja dans la base données, cela veut dire que que l'utilsateur a deja partagé l'article.
         * la fonction retourne alors false.
         */

        //11
        public Boolean CheckShare(ShareModel s)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM action_share where id_user= " + s.Id + " and id_article = "
                + getIdArtcileByLink(s.Link) + "";
            MySqlDataReader msdr = cmd.ExecuteReader();
            while (msdr.Read())
            {
                this.connection.Close();
                return true;
            }
            this.connection.Close();
            return false;
        }


        /*
         * la fonction permet à un utilsateur de partager un article.
         * la fonction prend en paramtere un objet ShareModel.
         * ShareModel contient l'id de l'utilisateur et le lien de l'article.
         * si la combinaison (id utilsateur, lien article) n'existe pas dans la base de données, 
         *      la fonction retourne true et insère le partage.
         * le score de l'article est augmenté.
         */

            //12
        public Boolean InsertShare(ShareModel shareModel)
        {
            string statement = String.Empty;
            if (CheckShare(shareModel))
            {
                this.connection.Close();
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "insert into action_share(id_user, id_article) values (" + shareModel.Id
                    + ",'" + getIdArtcileByLink(shareModel.Link) + "')";
                try
                {
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE article set score = score+"+VALEUR_PARTAGE_NOBADGE+" where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                catch
                {
                    this.connection.Close();
                    return false;
                }
            }
        }

        /*
         */

            //13
        public Boolean InsertShareBadge(ShareModel shareModel)
        {
            string statement = String.Empty, categorie = String.Empty;
            int scoreByCategorie = 0;

            if (CheckShare(shareModel))
            {
                this.connection.Close();
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();

                cmd.CommandText = "insert into action_share(id_user, id_article) values (" + shareModel.Id
                    + ",'" + getIdArtcileByLink(shareModel.Link) + "')";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }

                cmd.CommandText = "select categorie from article where link = '" + shareModel.Link + "'";
                MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    categorie = mySqlDataReader.GetString(0);
                }
                mySqlDataReader.Close();

                cmd.CommandText = "select `" + categorie + "` from utilisateur where id_user =" + shareModel.Id;
                mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    scoreByCategorie = mySqlDataReader.GetInt32(0);
                }
                mySqlDataReader.Close();
                cmd.CommandText = "UPDATE utilisateur set `" + categorie + "` = `" + categorie + "`+ "+GAIN_UTILISATEUR_PAR_PARTAGE+" where id_user = " + (shareModel.Id);
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }
                mySqlDataReader.Close();

                //si le score de l'utilsiateur dans une catégorie est superiereur à ce nombre
                if (scoreByCategorie >= SEUIL_OR)
                {
                    cmd.CommandText = "UPDATE article set score = score+"+SCORE_ARTICLE_OR_PARTAGE+" where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else if (scoreByCategorie >= SEUIL_ARGENT)
                {
                    cmd.CommandText = "UPDATE article set score = score+"+ SCORE_ARTICLE_ARGENT_PARTAGE+ " where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else if (scoreByCategorie >= SEUIL_BRONZE)
                {
                    cmd.CommandText = "UPDATE article set score = score+" + SCORE_ARTICLE_BRONZE_PARTAGE + " where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else
                {
                    cmd.CommandText = "UPDATE article set score = score+"+ VALEUR_PARTAGE_NOBADGE +" where id_article = " +
                        getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
            }
        }

        //14
        public List<Comment> getComments(string id)
        {
            List<Comment> commentaires = new List<Comment>();
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select u.nom, u.picture, c.commentaire from utilisateur u, commentaire c where u.id_user = c.id_utilisateur and c.id_article =" + id;
            MySqlDataReader msdr = cmd.ExecuteReader();
            while (msdr.Read())
            {
                commentaires.Add(new Comment(msdr.GetString(0), msdr.GetString(2), msdr.GetString(1)));
            }
            msdr.Close();
            this.connection.Close();
            return commentaires;
        }


        //15
        public Boolean CheckLike(ShareModel s)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM action_like where id_user= " + s.Id + " and id_article = "
                + getIdArtcileByLink(s.Link) + "";
            MySqlDataReader msdr = cmd.ExecuteReader();
            while (msdr.Read())
            {
                this.connection.Close();
                return true;
            }
            this.connection.Close();
            return false;
        }


        //16
        public Boolean InsertLike(ShareModel shareModel)
        {
            string statement = String.Empty;
            if (CheckLike(shareModel))
            {
                this.connection.Close();
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "insert into action_like(id_user, id_article) values (" + shareModel.Id
                    + ",'" + getIdArtcileByLink(shareModel.Link) + "')";
                try
                {
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE article set score = score+"+VALEUR_LIKE_NOBADGE+" where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                catch
                {
                    this.connection.Close();
                    return false;
                }

            }

        }


        //17
        public Boolean RemoveLike(string ida, string idu)
        {
            string statement = String.Empty;
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "DELETE FROM action_like where id_user = " + idu + " and id_article = " + ida;

            try
            {
                cmd.ExecuteNonQuery();
                cmd.CommandText = "UPDATE article set score = score-" + VALEUR_LIKE_NOBADGE + " where id_article = " + ida;
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    return true;
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }

            }
            catch
            {
                this.connection.Close();
                return false;
            }
        }


        //18
        public Boolean InsertLikeBadge(ShareModel shareModel)
        {
            string statement = String.Empty, categorie = String.Empty;
            int scoreByCategorie = 0;

            if (CheckLike(shareModel))
            {
                this.connection.Close();
                return false;
            }
            else
            {
                connection = new MySqlConnection(this.urlConnection);
                connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();

                cmd.CommandText = "insert into action_like(id_user, id_article) values (" + shareModel.Id
                    + ",'" + getIdArtcileByLink(shareModel.Link) + "')";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }

                cmd.CommandText = "select categorie from article where link = '" + shareModel.Link + "'";
                MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    categorie = mySqlDataReader.GetString(0);
                }
                mySqlDataReader.Close();

                cmd.CommandText = "select `" + categorie + "` from utilisateur where id_user =" + shareModel.Id;
                mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    scoreByCategorie = mySqlDataReader.GetInt32(0);
                }
                mySqlDataReader.Close();
                cmd.CommandText = "UPDATE utilisateur set `" + categorie + "` = `" + categorie + "`+"+GAIN_UTILISATEUR_PAR_LIKE+" where id_user = " + (shareModel.Id);
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }
                mySqlDataReader.Close();

                if (scoreByCategorie >= SEUIL_OR)
                {
                    cmd.CommandText = "UPDATE article set score = score+"+SCORE_ARTICLE_OR_LIKE+" where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else if (scoreByCategorie >= SEUIL_ARGENT)
                {
                    cmd.CommandText = "UPDATE article set score = score+"+ SCORE_ARTICLE_ARGENT_LIKE + " where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else if (scoreByCategorie >= SEUIL_BRONZE)
                {
                    cmd.CommandText = "UPDATE article set score = score+" + SCORE_ARTICLE_BRONZE_LIKE + " where id_article = " + getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
                else
                {
                    cmd.CommandText = "UPDATE article set score = score+"+ VALEUR_LIKE_NOBADGE + " where id_article = " +
                        getIdArtcileByLink(shareModel.Link);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        this.connection.Close();
                        return true;
                    }
                    catch
                    {
                        this.connection.Close();
                        return false;
                    }

                }
            }
        }


        //19
        public Boolean RemoveLikeBadge(string idu, string ida)
        {
            string statement = String.Empty, categorie = String.Empty;
            int scoreByCategorie = 0;
            int categorieOfArticle = 0;
            MySqlDataReader mySqlDataReader;

            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();

            cmd.CommandText = "DELETE FROM action_like where id_user = "+idu+" and id_article = "+ida;

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return false;
            }

            cmd.CommandText = "SELECT categorie FROM article where id_article = " + ida;
            try
            {
                mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    categorieOfArticle = mySqlDataReader.GetInt32(0);
                }
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return false;
            }
            mySqlDataReader.Close();

            cmd.CommandText = "SELECT `" + categorieOfArticle + "` FROM utilisateur where id_user = " + idu;
            try
            {
                mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    scoreByCategorie = mySqlDataReader.GetInt32(0);
                }
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return false;
            }
            mySqlDataReader.Close();

            cmd.CommandText = "UPDATE utilisateur set `" + categorieOfArticle + "` = `" + categorieOfArticle + "` - " + GAIN_UTILISATEUR_PAR_LIKE + " where id_user = " + idu;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return false;
            }
            mySqlDataReader.Close();

            if (scoreByCategorie >= SEUIL_OR)
            {
                cmd.CommandText = "UPDATE article set score = score - " + SCORE_ARTICLE_OR_LIKE + " where id_article = " + ida;
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch(MySqlException e)
                {
                    this.connection.Close();
                    return false;
                }
            }
            else if( scoreByCategorie >= SEUIL_ARGENT )
            {
                cmd.CommandText = "UPDATE article set score = score - " + SCORE_ARTICLE_ARGENT_LIKE + " where id_article = " + ida;
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch(MySqlException e)
                {
                    this.connection.Close();
                    return false;
                }
            }
            else if( scoreByCategorie >= SEUIL_BRONZE)
            {
                cmd.CommandText = "UPDATE article set score = score - " + SCORE_ARTICLE_BRONZE_LIKE + " where id_article = " + ida;
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch(MySqlException e)
                {
                    this.connection.Close();
                    return false;
                }
            }
            else
            {
                cmd.CommandText = "UPDATE article set score = score - " + VALEUR_LIKE_NOBADGE + " where id_article = " + ida;
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException e)
                {
                    this.connection.Close();
                    return false;
                }
            }
            this.connection.Close();
            return true; 
        }


        //20
        public List<Article> GetLikedArticlesByUser(string id)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            List<Article> articles = new List<Article>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select a.id_article, a.source, a.titre, a.link, a.description, a.image, a.score, a.categorie, a.publishDate " +
                " from action_like, utilisateur, article a where " +
                "action_like.id_user = utilisateur.id_user and action_like.id_article = a.id_article and " +
                "utilisateur.id_user = " + id + " ;";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Id = mySqlDataReader.GetInt32(0).ToString();
                article.Source = mySqlDataReader.GetString(1);
                article.Titre = mySqlDataReader.GetString(2);
                article.Link = mySqlDataReader.GetString(3);
                article.Description = mySqlDataReader.GetString(4);
                try
                {
                    article.Image = mySqlDataReader.GetString(5);
                    article.Categorie = mySqlDataReader.GetString(10);
                }
                catch
                {
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(6);
                article.PublishDate = mySqlDataReader.GetDateTime(8).ToString();
                articles.Add(article);
            }
            mySqlDataReader.Close();
            this.connection.Close();
            return articles;
        }


        //21
        public string PostCommentaire(Commentaire commentaire)
        {
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            List<int> articles = new List<int>();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "insert into commentaire(id_utilisateur, id_article, commentaire) values (" + commentaire.IdUtilisateur + "," + commentaire.IdArticle + ",'" + commentaire.Contenu.Replace("'", "''") + "')";
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "true";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }


        //22
        public Utilisateur GetUtilisateur(string id)
        {
            var utilisateur = new Utilisateur();
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select * from utilisateur where id_user = " + id;
            MySqlDataReader mySqlDataReader;

            try
            {
                mySqlDataReader = cmd.ExecuteReader();
                while (mySqlDataReader.Read())
                {
                    utilisateur.Id_user = mySqlDataReader.GetInt64(0);
                    utilisateur.Nom = mySqlDataReader.GetString(1);
                    utilisateur.Score1 = mySqlDataReader.GetInt32(2);
                    utilisateur.Score2 = mySqlDataReader.GetInt32(3);
                    utilisateur.Score3 =  mySqlDataReader.GetInt32(4);
                    utilisateur.Score4 = mySqlDataReader.GetInt32(5);
                    utilisateur.Score5 =  mySqlDataReader.GetInt32(6);
                    utilisateur.Score6 =  mySqlDataReader.GetInt32(7);
                    utilisateur.Score7 =  mySqlDataReader.GetInt32(8);
                    utilisateur.Score8 =  mySqlDataReader.GetInt32(9);
                    utilisateur.Score9 =  mySqlDataReader.GetInt32(10);
                    //utilisateur.Score10 =  mySqlDataReader.GetInt32(11);
                    //utilisateur.Score11 =  mySqlDataReader.GetInt32(12);
                    //utilisateur.Score12 =  mySqlDataReader.GetInt32(13);
                    utilisateur.Picture = mySqlDataReader.GetString(11);
                    utilisateur.Badge = mySqlDataReader.GetInt16(12);
                    utilisateur.Role = mySqlDataReader.GetString(13);
                }

                mySqlDataReader.Close();
                this.connection.Close();
                return utilisateur;
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return utilisateur;
            }
        }


        //23
        public List<int> GetScores(string id)
        {
            List<int> scores = new List<int>();
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `10`, `11`, `12` from utilisateur where id_user = " + id;
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
            try
            {

                while (mySqlDataReader.Read())
                {
                    scores.Add(mySqlDataReader.GetInt32(0));
                    scores.Add(mySqlDataReader.GetInt32(1));
                    scores.Add(mySqlDataReader.GetInt32(2));
                    scores.Add(mySqlDataReader.GetInt32(3));
                    scores.Add(mySqlDataReader.GetInt32(4));
                    scores.Add(mySqlDataReader.GetInt32(5));
                    scores.Add(mySqlDataReader.GetInt32(6));
                    scores.Add(mySqlDataReader.GetInt32(7));
                    scores.Add(mySqlDataReader.GetInt32(8));
                    scores.Add(mySqlDataReader.GetInt32(9));
                    scores.Add(mySqlDataReader.GetInt32(10));
                    scores.Add(mySqlDataReader.GetInt32(11));
                }
                mySqlDataReader.Close();
                this.connection.Close();
                return scores;
            }
            catch
            {
                mySqlDataReader.Close();
                return scores;

            }
        }


        //24
        public string addShareDetails(string ida, string idaf, string date, string idu)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "INSERT INTO share_details (id_article, id_article_facebook, date, id_user) VALUES (" + ida + " , '" + idaf + "', '" + date + "' , " + idu + ");";

            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "true"; 
            }catch(MySqlException e)
            {
                this.connection.Close();
                return "false " +  e.Message; 
            }
        }

        public List<string> getIdafsUsers(string idu)
        {
            List<string> idafs = new List<string>();
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select id_article_facebook from share_details where id_user = " + idu;
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                idafs.Add(mySqlDataReader.GetString(0));
            }
            mySqlDataReader.Close();
            this.connection.Close();
            return idafs;
        }


        //25
        public Boolean removeShareDetails(string idu, string idaf)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "DELETE FROM share_details WHERE id_user = " + idu + " AND id_article_facebook LIKE '" + idaf + "'";
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return true; 
            }
            catch
            {
                this.connection.Close();
                return false; 
            }
        }


        //26
        public Boolean UpdatePicture(User user)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "UPDATE utilisateur set picture = '"+user.Picture+"' where id_user = "+ user.Id +" and nom LIKE '"+user.Nom+"'";
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return true;
            }
            catch
            {
                this.connection.Close();
                return false;
            }
        }


        //27
        public List<Utilisateur> getAllUsers()
        {
            var users = new List<Utilisateur>();
            connection = new MySqlConnection(this.urlConnection);
            connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select * from utilisateur";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();
            try
            {

                while (mySqlDataReader.Read())
                {
                    var utilisateur = new Utilisateur();
                    utilisateur.Id_user = mySqlDataReader.GetInt64(0);
                    utilisateur.Nom = mySqlDataReader.GetString(1);
                    utilisateur.Score1 = mySqlDataReader.GetInt32(2);
                    utilisateur.Score2 = mySqlDataReader.GetInt32(3);
                    utilisateur.Score3 = mySqlDataReader.GetInt32(4);
                    utilisateur.Score4 = mySqlDataReader.GetInt32(5);
                    utilisateur.Score5 = mySqlDataReader.GetInt32(6);
                    utilisateur.Score6 = mySqlDataReader.GetInt32(7);
                    utilisateur.Score7 = mySqlDataReader.GetInt32(8);
                    utilisateur.Score8 = mySqlDataReader.GetInt32(9);
                    utilisateur.Score9 = mySqlDataReader.GetInt32(10);
                    //utilisateur.Score10 = mySqlDataReader.GetInt32(11);
                    //utilisateur.Score11 = mySqlDataReader.GetInt32(12);
                    //utilisateur.Score12 = mySqlDataReader.GetInt32(13);
                    utilisateur.Picture = mySqlDataReader.GetString(11);
                    utilisateur.Badge = mySqlDataReader.GetInt16(12);
                    utilisateur.Role = mySqlDataReader.GetString(13);
                    users.Add(utilisateur);
                }

                mySqlDataReader.Close();
                this.connection.Close();
                return users;
            }
            catch (MySqlException e)
            {
                mySqlDataReader.Close();
                this.connection.Close();
                throw (e);
            }
        }


        //28
        public Boolean addAdmin(string id)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update utilisateur set role = 'admin' where id_user = " + id;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return true;
            }catch(MySqlException e)
            {
                this.connection.Close();
                throw e;
            }
        }


        //29
        public Boolean removeAdmin(string id)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update utilisateur set role = 'user' where id_user = " + id;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return true;
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                throw e;
            }
        }

        //30
        public string executor(Request request)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = ""+request.Content;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "Request Ok ! ";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return "error : " + e;
            }
        }


        //31
        public Boolean UpdateBadge(User user, Boolean b)
        {
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();

            if (b)
            {
                cmd.CommandText = "UPDATE utilisateur set badge = 1 where id_user = " + user.Id + " and nom LIKE '" + user.Nom + "'";
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    return true;
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }
            }
            else
            {
                cmd.CommandText = "UPDATE utilisateur set badge = 0 where id_user = " + user.Id + " and nom LIKE '" + user.Nom + "'";
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    return true;
                }
                catch
                {
                    this.connection.Close();
                    return false;
                }
            }
        }


        //32
        public Seuils getSeuils()
        {
            var seuils = new Seuils();
            this.connection = new MySqlConnection(this.urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM seuils;";
            MySqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    seuils.Bronze = reader.GetInt32(0);
                    seuils.Silver = reader.GetInt32(1);
                    seuils.Gold = reader.GetInt32(2);
                }
                this.connection.Close();
                return seuils;
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                throw e;
            }
        }


        //33
        public string updateBronze(Seuils newSeuils)
        {
            var seuils = this.getSeuils();

            if(newSeuils.Bronze >= seuils.Silver)
            {
                this.connection.Close();
                return "Le seuil de Bronze ne peut pas être supérieur au Seuil argent ou gold.";
            }
            else if(newSeuils.Bronze >= (seuils.Silver - 10))
            {
                this.connection.Close();
                return "l'ecart entre deux seuils doit être minimum de 10.";
            }
            else
            {
                this.connection = new MySqlConnection(urlConnection);
                this.connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "update seuils set bronze = " + newSeuils.Bronze;
                try
                {
                    cmd.ExecuteNonQuery();
                    SEUIL_BRONZE = newSeuils.Bronze;
                    this.connection.Close();
                    return "Opération Validée";
                }
                catch(MySqlException e)
                {
                    this.connection.Close();
                    return e.Message;
                }
            }
        }


        //34
        public string updateSilver(Seuils newSeuils)
        {
            var seuils = this.getSeuils();

            if (newSeuils.Silver >= seuils.Gold)
            {
                this.connection.Close();
                return "Le seuil de Silver ne peut pas être supérieur au Seuil Gold.";
            }
            else if( newSeuils.Silver <= seuils.Bronze + 10)
            {
                this.connection.Close();
                return "Le seuil de Silver ne peut pas être inférieur au Seuil Bronze plus un écart de 10 (Bronze + 10).";
            }
            else
            {
                this.connection = new MySqlConnection(urlConnection);
                this.connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "update seuils set silver = " + newSeuils.Silver;
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    SEUIL_ARGENT = newSeuils.Silver;
                    return "Opération Validée";
                }
                catch (MySqlException e)
                {
                    this.connection.Close();
                    return e.Message;
                }
            }
        }


        //35
        public string updateGold(Seuils newSeuils)
        {
            var seuils = this.getSeuils();

            if (newSeuils.Gold <= seuils.Silver + 10)
            {
                this.connection.Close();
                return "Le seuil de Gold ne peut pas être supérieur au Seuil Silver plus un écart de dix (Silver + 10).";
            }
            else
            {
                this.connection = new MySqlConnection(urlConnection);
                this.connection.Open();
                MySqlCommand cmd = this.connection.CreateCommand();
                cmd.CommandText = "update seuils set gold = " + newSeuils.Gold;
                try
                {
                    cmd.ExecuteNonQuery();
                    this.connection.Close();
                    SEUIL_OR =  newSeuils.Gold;
                    return "Opération Validée";
                }
                catch (MySqlException e)
                {
                    this.connection.Close();
                    return e.Message;
                }
            }
        }

        //36
        public Influence getInfluences()
        {
            var influences = new Influence();
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM influence";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                influences.Like_no_badge = mySqlDataReader.GetInt32(0);
                influences.Share_no_badge = mySqlDataReader.GetInt32(1);
                influences.User_for_like = mySqlDataReader.GetInt32(2);
                influences.User_for_share = mySqlDataReader.GetInt32(3);
                influences.Like_bronze = mySqlDataReader.GetInt32(4);
                influences.Like_silver = mySqlDataReader.GetInt32(5);
                influences.Like_gold = mySqlDataReader.GetInt32(6);
                influences.Share_bronze = mySqlDataReader.GetInt32(7);
                influences.Share_silver = mySqlDataReader.GetInt32(8);
                influences.Share_gold = mySqlDataReader.GetInt32(9);
            }

            this.connection.Close();
            mySqlDataReader.Close();
            return influences;
        }

        //37
        public string updateLike_no_badge(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set like_no_badge = " + newInfluence.Like_no_badge;
            try
            {
                cmd.ExecuteNonQuery();
                VALEUR_LIKE_NOBADGE = newInfluence.Like_no_badge;
                this.connection.Close();
                return "Opération Validée : Modification like no badge";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
            
        }


        //38
        public string updateShare_no_badge(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set share_no_badge = " + newInfluence.Share_no_badge;
            try
            {
                cmd.ExecuteNonQuery();
                VALEUR_PARTAGE_NOBADGE = newInfluence.Share_no_badge;
                this.connection.Close();
                return "Opération Validée : Modification share no badge";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //39
        public string updateUser_for_like(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set user_for_like = " + newInfluence.User_for_like;
            try
            {
                cmd.ExecuteNonQuery();
                GAIN_UTILISATEUR_PAR_LIKE = newInfluence.User_for_like;
                this.connection.Close();
                return "Opération Validée : Modification User for like";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //40
        public string updateUser_for_share(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set user_for_share = " + newInfluence.User_for_share;
            try
            {
                cmd.ExecuteNonQuery();
                GAIN_UTILISATEUR_PAR_PARTAGE = newInfluence.User_for_share;
                this.connection.Close();
                return "Opération Validée : Modification User for share";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //41
        public string updateLike_bronze(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set like_bronze = " + newInfluence.Like_bronze;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_BRONZE_LIKE = newInfluence.Like_bronze;
                this.connection.Close();
                return "Opération Validée : Modification Like bronze";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //42
        public string updateLike_silver(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set like_silver = " + newInfluence.Like_silver;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_ARGENT_LIKE = newInfluence.Like_bronze;
                this.connection.Close();
                return "Opération Validée : Modification Like silver";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //43
        public string updateLike_gold(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set like_gold = " + newInfluence.Like_gold;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_OR_LIKE = newInfluence.Like_gold;
                this.connection.Close();
                return "Opération Validée : Modification Like gold";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //44
        public string updateShare_bronze(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set share_bronze = " + newInfluence.Share_bronze;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_BRONZE_PARTAGE = newInfluence.Share_bronze;
                this.connection.Close();
                return "Opération Validée : Modification Share bronze";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //45
        public string updateShare_silver(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set share_silver = " + newInfluence.Share_silver;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_ARGENT_PARTAGE = newInfluence.Share_silver;
                this.connection.Close();
                return "Opération Validée : Modification Share silver";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //46
        public string updateShare_gold(Influence newInfluence)
        {
            var influences = this.getInfluences();

            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update influence set share_gold = " + newInfluence.Share_gold;
            try
            {
                cmd.ExecuteNonQuery();
                SCORE_ARTICLE_OR_PARTAGE = newInfluence.Share_gold;
                this.connection.Close();
                return "Opération Validée : Modification Share gold";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //47
        public string giveBadge(string id)
        {
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update utilisateur set badge = 1 where id_user = "+id;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "Opération Validée : Ajout du badge";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //48
        public string removeBadge(string id)
        {
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update utilisateur set badge = 0 where id_user = " + id;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "Opération Validée : Suppression du badge";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        //50
        public string setNewPoint(int number)
        {
            int oldValue = this.getNewPoint();
            int difference = oldValue - number;
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();

            cmd.CommandText = "update article set score = score - " + difference + " where new = 1";

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch
            {
                return "An erreur occured in the server when remove difference from new articles";
            }

            cmd.CommandText = "update regression set value = " + number;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "Opération Validée : Changement de la valeur fait avec succès";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        public int getNewPoint()
        {
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            int value = 0;
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM regression";
            MySqlDataReader reader = cmd.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    value = reader.GetInt32(0);
                }
            }
            catch (MySqlException e)
            {
                this.connection.Close();
            }
            this.connection.Close();
            return value;
        }

        //49
        public string doRegression()
        {
            int value = 0;
            try
            {
                value = this.getNewPoint();
            }
            catch(Exception e)
            {
                throw e;
            }
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update article set score = score - " +value+ ", new = 0 where publishDate < DATE_ADD(now(), INTERVAL -1 DAY) and new = 1;";
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return "Opération Validée : Régression faite avec succès";
            }
            catch (MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
        }

        public List<string> getsources()
        {
            List<string> sources = new List<string>();
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT distinct source FROM article";
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string source = reader.GetString(0);
                sources.Add(source);
            }
            connection.Close();
            return sources;
        }

        public int getSourceScore(string source)
        {
            int score = 0;
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select sum(score) from article where source like '"+source+"'";
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                score = reader.GetInt32(0);
            }
            connection.Close();
            return score;
        }

        public string addBonusToSource(string source, int bonus)
        {
            source.Replace("'","''");
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "update article set score = score + "+bonus+" where source like '"+source+"';";

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return e.Message;
            }
            connection.Close();

            if(bonus < 0)
            {
                return "Malus ajouté avec succès !";
            }
            else
            {
                return "Bonus ajouté avec succès !";
            }
        }

        public int sourceCounter(string source)
        {
            source.Replace("'", "''");
            int score = 0;
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select count(*) from article where source like '" + source + "'";
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                score = reader.GetInt32(0);
            }
            connection.Close();
            return score;
        }

        public int getNewBySource(string source)
        {
            int score = 0;
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select count(*) from article where source like '" + source + "' and new = 1";
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                score = reader.GetInt32(0);
            }
            connection.Close();
            return score;
        }

        public int getOldBySource(string source)
        {
            int score = 0;
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select count(*) from article where source like '" + source + "' and new = 0";
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                score = reader.GetInt32(0);
            }
            connection.Close();
            return score;
        }

        public Boolean insertUnclassified(Article article)
        {
            Article a = article; 
            string statement = "INSERT INTO tolabelize (source, titre, link, description, image, categorie, score, new) values ('"
                       + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
                       + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
                       + article.Image.Replace("'", "''") + "',0, 0, 0)";
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = statement;
            
            try
            {
                cmd.ExecuteNonQuery();  
            }
            catch(MySqlException e)
            {
          
            }
            statement = String.Empty;
            statement = "INSERT INTO article (source, titre, link, description, image, categorie, score, new) values ('"
               + article.Source.Replace("'", "''") + "', '" + article.Titre.Replace("'", "''") + "', '"
               + article.Link.Replace("'", "''") + "', '" + article.Description.Replace("'", "''") + "', '"
               + article.Image.Replace("'", "''") + "', 10 , 0, 0)";

            cmd.CommandText = statement;
            try
            {
                cmd.ExecuteNonQuery();
                this.connection.Close();
                return true; 
            }
            catch(MySqlException e)
            {
                this.connection.Close();
                return false;
            }
        }

        public List<Article> getUnclassified()
        {
            List<Article> articles = new List<Article>();
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM tolabelize;";
            MySqlDataReader mySqlDataReader =  cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                Article article = new Article();
                article.Id = mySqlDataReader.GetInt32(0).ToString();
                article.Source = mySqlDataReader.GetString(1);
                article.Titre = mySqlDataReader.GetString(2);
                article.Link = mySqlDataReader.GetString(3);
                article.Description = mySqlDataReader.GetString(4);
                try
                {
                    article.Image = mySqlDataReader.GetString(5);
                    article.Categorie = mySqlDataReader.GetString(11);
                }
                catch
                {
                    //You can add some treats here
                }
                article.Score = mySqlDataReader.GetInt32(6);
                article.PublishDate = mySqlDataReader.GetDateTime(8).ToString();
                articles.Add(article);
            }

            this.connection.Close();
            return articles;
        }

        public string classifyArticle(Article article)
        {
            string result = "";
            List<Article> articles = new List<Article>();
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();

            int id = this.getIdArtcileByLink(article.Link);
            string categorie = article.Categorie;

            cmd.CommandText = "update article set categorie = "+categorie+" where id_article = "+id;
            try
            {
                cmd.ExecuteNonQuery();
                result = "ok";
            }
            catch
            {
                result = "notok";
            }
            this.connection.Close();

            if(result == "ok")
            {
                this.connection.Open();
                cmd = this.connection.CreateCommand();
                cmd.CommandText = "DELETE FROM tolabelize WHERE id_article = " + article.Id;
                try {
                    cmd.ExecuteNonQuery();
                    result = "Opération validée avec succès ! ";
                }
                catch
                {
                    result = "un problème a surgit tel un guepard ! ";
                }
                this.connection.Close();
            }
            return result;
        }

        public List<ArticleCategory> getCategories()
        {
            List<ArticleCategory> categories = new List<ArticleCategory>();
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "SELECT * FROM categorie;";
            MySqlDataReader mySqlDataReader = cmd.ExecuteReader();

            while (mySqlDataReader.Read())
            {
                ArticleCategory c = new ArticleCategory();
                c.Id = mySqlDataReader.GetInt32(0);
                c.Name = mySqlDataReader.GetString(1);
                categories.Add(c);
            }

            this.connection.Close();
            return categories;
        }

        public List<Track> getTrackList(int ida)
        {
            this.connection = new MySqlConnection(urlConnection);
            this.connection.Open();
            MySqlCommand cmd = this.connection.CreateCommand();
            cmd.CommandText = "select s.id_user, s.id_article_facebook, u.nom, s.date from share_details s, utilisateur u where s.id_user = u.id_user and s.id_article = " + ida;
            List<Track> tracks = new List<Track>();
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Track t = new Track();
                t.Id = reader.GetInt64(0).ToString();
                t.Idf = reader.GetString(1);
                t.Name = reader.GetString(2);
                t.Date = reader.GetString(3);

                tracks.Add(t);
            }
            this.connection.Close();
            return tracks;
        }

        public string calculAverageBySource()
        {
            List<string> sources = this.getsources();
            this.connection = new MySqlConnection(this.urlConnection);
            MySqlCommand cmd = this.connection.CreateCommand();
            this.connection.Open();

            foreach (string source in sources)
            {
                cmd.CommandText = String.Empty;
                int oldNews = this.getOldBySource(source);
                int newNews = this.getNewBySource(source);
                int sumScoreOld = 0;
                cmd.CommandText = "SELECT SUM(score) from article where new = 0 and source like '" + source + "' ;";
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    sumScoreOld = reader.GetInt32(0);
                }
                int sumScoreNew = 0;
                reader.Close();
                cmd.CommandText = "select sum(score - (select * from regression) ) as sumScoreNew from article where new = 1 and source like '" + source + "'";
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    sumScoreNew = reader.GetInt32(0); 
                }
                int sourceCounter = this.sourceCounter(source);

                int avg = (sumScoreNew + sumScoreOld) / sourceCounter;
                reader.Close();
                cmd.CommandText = String.Empty;
                cmd.CommandText = "update article set avg_source = " + avg + " where source like '"+source+"'";
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch(MySqlException e)
                {
                    this.connection.Close();
                    throw e;
                    return "An error has occured when calculing average " +avg ;
                }
            }

            return "Averages calculated with success";
        }
    }
}
